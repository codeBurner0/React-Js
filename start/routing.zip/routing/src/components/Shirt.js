import React from 'react'
import Images from './Images'
function Shirt() {
  return (
    <div className='pos'>
      <Images  imge="https://source.unsplash.com/random/700x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/701x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/702x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/703x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/704x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/705x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/706x400/?shirt"/>
      <Images  imge="https://source.unsplash.com/random/707x400/?shirt"/>
    </div>
  )
}

export default Shirt
