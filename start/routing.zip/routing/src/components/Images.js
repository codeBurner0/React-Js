import React from 'react'
import './images.css'
function Images({imge}) {
  return (
    <div >
      <img src={imge} alt=''/>
    </div>
  )
}

export default Images;
