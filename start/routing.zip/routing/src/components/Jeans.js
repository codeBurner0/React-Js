import React from 'react'
import Images from './Images'
function Jeans() {
  return (
    <div>
      <div className='pos'>
      <Images  imge="https://source.unsplash.com/random/700x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/701x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/702x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/703x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/704x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/705x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/706x400/?jeans"/>
      <Images  imge="https://source.unsplash.com/random/707x400/?jeans"/>
    </div>
    </div>
  )
}

export default Jeans
